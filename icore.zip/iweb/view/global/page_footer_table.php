<?php
///view/global/page_footer_table.php
include './iweb/controller/global/page_footer_table.php';
include './iweb/template/global/page_footer_table.php';
