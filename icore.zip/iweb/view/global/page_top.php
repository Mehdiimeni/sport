<?php
///view/global/page_top.php
include './iweb/controller/global/page_top.php';
include './iweb/template/global/page_top.php';
