<?php
///view/global/top_bar.php
include './iweb/controller/global/top_bar.php';
include './iweb/template/global/top_bar.php';
