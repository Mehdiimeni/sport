<?php
///view/global/horizontal_menu.php
include './iweb/controller/global/horizontal_menu.php';
include './iweb/template/global/horizontal_menu.php';
