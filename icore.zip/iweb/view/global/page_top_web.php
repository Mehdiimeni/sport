<?php
///view/global/page_top_web.php
include './iweb/controller/global/page_top_web.php';
include './iweb/template/global/page_top_web.php';
