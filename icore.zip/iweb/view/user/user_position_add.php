<?php
///view/user/user_position_add.php
include './iweb/controller/user/user_position_add.php';
include './iweb/template/user/user_position_add.php';
