<?php
///view/user/logout.php
include './iweb/controller/user/logout.php';
include './iweb/template/user/logout.php';
