<?php
///view/user/payment.php
include './iweb/controller/user/payment.php';
include './iweb/template/user/payment.php';
