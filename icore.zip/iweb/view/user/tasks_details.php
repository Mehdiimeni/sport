<?php
///view/user/tasks_details.php
include './iweb/controller/user/tasks_details.php';
include './iweb/template/user/tasks_details.php';
