<?php
///view/first/card_register.php
include './iweb/controller/first/card_register.php';
include './iweb/template/first/card_register.php';
