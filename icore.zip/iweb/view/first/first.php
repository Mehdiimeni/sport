<?php
///view/first/first.php
include './iweb/controller/first/first.php';
include './iweb/template/first/first.php';
