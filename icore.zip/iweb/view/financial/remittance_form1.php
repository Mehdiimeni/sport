<?php
///view/financial/remittance_form1.php
include './iweb/controller/financial/remittance_form1.php';
include './iweb/template/financial/remittance_form1.php';
