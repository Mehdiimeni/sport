<?php
///controller/global/top_bar.php
$config = Configuration::getInstance();
$allLanguages = $config->getConfig('allLanguage');