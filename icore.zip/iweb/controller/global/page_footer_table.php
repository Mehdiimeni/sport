<?php
///controller/global/page_footer_table.php
