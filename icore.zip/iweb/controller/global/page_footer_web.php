<?php
///controller/global/page_footer_web.php
