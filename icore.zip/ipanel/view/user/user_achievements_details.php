<?php
///view/user/user_achievements_details.php
include './controller/user/user_achievements_details.php';
include './template/user/user_achievements_details.php';
