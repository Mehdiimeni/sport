<?php
///view/organization/federations.php
include './controller/organization/federations.php';
include './template/organization/federations.php';
