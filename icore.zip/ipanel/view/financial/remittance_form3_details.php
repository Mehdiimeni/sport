<?php
///view/financial/remittance_form3_details.php
include './controller/financial/remittance_form3_details.php';
include './template/financial/remittance_form3_details.php';
