<?php
///view/financial/remittance_operation2_details.php
include './controller/financial/remittance_operation2_details.php';
include './template/financial/remittance_operation2_details.php';
