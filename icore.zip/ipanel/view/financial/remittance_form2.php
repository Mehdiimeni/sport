<?php
///view/financial/remittance_form2.php
include './controller/financial/remittance_form2.php';
include './template/financial/remittance_form2.php';
