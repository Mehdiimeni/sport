<?php
///view/financial/remittance_operation3.php
include './controller/financial/remittance_operation3.php';
include './template/financial/remittance_operation3.php';
