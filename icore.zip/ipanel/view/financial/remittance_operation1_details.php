<?php
///view/financial/remittance_operation1_details.php
include './controller/financial/remittance_operation1_details.php';
include './template/financial/remittance_operation1_details.php';
