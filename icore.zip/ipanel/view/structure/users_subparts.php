<?php
///view/structure/users_subparts.php
include './controller/structure/users_subparts.php';
include './template/structure/users_subparts.php';
