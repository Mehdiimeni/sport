<?php
///view/structure/user_operation.php
include './controller/structure/user_operation.php';
include './template/structure/user_operation.php';
