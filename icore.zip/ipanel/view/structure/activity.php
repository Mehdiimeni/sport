<?php
///view/structure/activity.php
include './controller/structure/activity.php';
include './template/structure/activity.php';
