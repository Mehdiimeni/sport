<?php
///view/structure/user_access.php
include './controller/structure/user_access.php';
include './template/structure/user_access.php';
