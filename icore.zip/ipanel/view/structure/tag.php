<?php
///view/structure/tag.php
include './controller/structure/tag.php';
include './template/structure/tag.php';
