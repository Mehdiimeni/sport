<?php
///view/global/page_css.php
include './controller/global/page_css.php';
include './template/global/page_css.php';
