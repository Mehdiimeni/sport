<?php
///view/global/page_footer.php
include './controller/global/page_footer.php';
include './template/global/page_footer.php';
