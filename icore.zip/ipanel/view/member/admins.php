<?php
///view/member/admins.php
include './controller/member/admins.php';
include './template/member/admins.php';
