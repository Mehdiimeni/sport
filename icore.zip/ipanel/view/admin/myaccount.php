<?php
///view/admin/myaccount.php
include './controller/admin/myaccount.php';
include './template/admin/myaccount.php';
