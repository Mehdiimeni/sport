<?php
///view/admin/logout.php
include './controller/admin/logout.php';
include './template/admin/logout.php';
