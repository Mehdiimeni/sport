<?php
///controller/global/page_footer.php
