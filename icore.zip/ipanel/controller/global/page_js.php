<?php
///controller/global/page_js.php
