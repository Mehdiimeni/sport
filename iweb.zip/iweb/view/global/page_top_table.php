<?php
///view/global/page_top_table.php
include './iweb/controller/global/page_top_table.php';
include './iweb/template/global/page_top_table.php';
