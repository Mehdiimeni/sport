<?php
///view/user/login.php
include './iweb/controller/user/login.php';
include './iweb/template/user/login.php';
