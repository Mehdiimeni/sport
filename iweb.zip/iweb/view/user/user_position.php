<?php
///view/user/user_position.php
include './iweb/controller/user/user_position.php';
include './iweb/template/user/user_position.php';
