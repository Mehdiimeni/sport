<?php
///view/user/myaccount.php
include './iweb/controller/user/myaccount.php';
include './iweb/template/user/myaccount.php';
