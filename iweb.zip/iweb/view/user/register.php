<?php
///view/user/register.php
include './iweb/controller/user/register.php';
include './iweb/template/user/register.php';
