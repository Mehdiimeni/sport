<?php
///view/financial/remittance_form2_details.php
include './iweb/controller/financial/remittance_form2_details.php';
include './iweb/template/financial/remittance_form2_details.php';
