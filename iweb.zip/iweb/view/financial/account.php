<?php
///view/financial/account.php
include './iweb/controller/financial/account.php';
include './iweb/template/financial/account.php';
