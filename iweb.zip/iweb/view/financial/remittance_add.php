<?php
///view/financial/remittance_add.php
include './iweb/controller/financial/remittance_add.php';
include './iweb/template/financial/remittance_add.php';
