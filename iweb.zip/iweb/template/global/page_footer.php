<?php
///template/global/page_footer.php
?>
<!-- Footer Start -->
<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6">
                <script>document.write(new Date().getFullYear())</script>
                <?php echo _lang['company_copy_right']; ?>
            </div>
            <div class="col-md-6">
                <div class="text-md-end footer-links d-none d-md-block">
                    <!--    <a href="javascript: void(0);">About</a>
                                    <a href="javascript: void(0);">Support</a>
                                    <a href="javascript: void(0);">Contact Us</a> -->
                </div>
            </div>
        </div>
    </div>
</footer>
<!-- end Footer -->

</div>

<!-- ============================================================== -->
<!-- End Page content -->
<!-- ============================================================== -->

</div>
<!-- END wrapper -->


<!-- Vendor js -->
<script src="./itheme/panel/js/vendor.min.js"></script>

<!--  Select2 Plugin Js -->
<script src="./itheme/panel/vendor/select2/js/select2.min.js"></script>

<!-- Fullcalendar js -->
<script src="./itheme/panel/vendor/fullcalendar/main.min.js"></script>

<!-- Calendar App Demo js -->
<script src="./itheme/panel/js/pages/demo.calendar.js"></script>

<script src="./itheme/panel/vendor/dropzone/min/dropzone.min.js"></script>
<!-- init js -->
<script src="./itheme/panel/js/ui/component.fileupload.js"></script>

<!-- App js -->
<script src="./itheme/panel/js/app.min.js"></script>



<script src="./itheme/panel/vendor/twitter-bootstrap-wizard/jquery.bootstrap.wizard.min.js"></script>

<!-- Wizard Form Demo js -->
<script src="./itheme/panel/js/pages/demo.form-wizard.js"></script>
<script src = "./itheme/panel/js/ticket.js" ></script>
<script src="./itheme/panel/js/iw.js"></script>


</body>


</html>