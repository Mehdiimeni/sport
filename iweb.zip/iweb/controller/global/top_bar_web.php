<?php
///controller/global/top_bar_web.php
$config = Configuration::getInstance();
$allLanguages = $config->getConfig('allLanguage');