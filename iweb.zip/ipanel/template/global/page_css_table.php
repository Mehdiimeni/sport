<?php
///template/global/page_css_table.php
?>
<!-- Datatable css -->
<link href="../itheme/panel/vendor/datatables.net-bs5/css/dataTables.bootstrap5.min.css" rel="stylesheet"
        type="text/css" />
<link href="../itheme/panel/vendor/datatables.net-responsive-bs5/css/responsive.bootstrap5.min.css" rel="stylesheet"
        type="text/css" />
<link href="../itheme/panel/vendor/datatables.net-fixedcolumns-bs5/css/fixedColumns.bootstrap5.min.css" rel="stylesheet"
        type="text/css" />
<link href="../itheme/panel/vendor/datatables.net-fixedheader-bs5/css/fixedHeader.bootstrap5.min.css" rel="stylesheet"
        type="text/css" />
<link href="../itheme/panel/vendor/datatables.net-buttons-bs5/css/buttons.bootstrap5.min.css" rel="stylesheet"
        type="text/css" />
<link href="../itheme/panel/vendor/datatables.net-select-bs5/css/select.bootstrap5.min.css" rel="stylesheet"
        type="text/css" />
<link href="../itheme/panel/vendor/select2/css/select2.min.css" rel="stylesheet" type="text/css" />
<link href="../itheme/panel/vendor/daterangepicker/daterangepicker.css" rel="stylesheet" type="text/css" />
<link href="../itheme/panel/vendor/bootstrap-touchspin/jquery.bootstrap-touchspin.min.css" rel="stylesheet"
        type="text/css" />
<link href="../itheme/panel/vendor/bootstrap-datepicker/css/bootstrap-datepicker.min.css" rel="stylesheet"
        type="text/css" />
<link href="../itheme/panel/vendor/bootstrap-timepicker/css/bootstrap-timepicker.min.css" rel="stylesheet"
        type="text/css" />
<link href="../itheme/panel/vendor/flatpickr/flatpickr.min.css" rel="stylesheet" type="text/css" />
<script src="../itheme/panel/js/hyper-config.js"></script>
<link href="../itheme/panel/css/app-creative.min.css" rel="stylesheet" type="text/css" id="app-style" />
<link href="../itheme/panel/css/icons.min.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="../itheme/panel/css/multi-select.css">

</head>