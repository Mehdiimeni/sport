<?php
///template/global/page_css.php
?>

    <!-- Fullcalendar css -->
    <link href="../itheme/panel/vendor/fullcalendar/main.min.css" rel="stylesheet" type="text/css" />

    <!-- Theme Config Js -->
    <script src="../itheme/panel/js/hyper-config.js"></script>
    

    <!-- App css -->
    <link href="../itheme/panel/css/app-creative.min.css" rel="stylesheet" type="text/css" id="app-style" />

    <!-- Icons css -->
    <link href="../itheme/panel/css/icons.min.css" rel="stylesheet" type="text/css" />
</head>