<?php
///template/global/page_js_table.php
?>
<script src="../itheme/panel/js/vendor.min.js"></script>


<!-- Code Highlight js -->
<script src="../itheme/panel/vendor/highlightjs/highlight.pack.min.js"></script>
<script src="../itheme/panel/vendor/clipboard/clipboard.min.js"></script>
<script src="../itheme/panel/js/hyper-syntax.js"></script>



<!-- Datatables js -->
<script src="../itheme/panel/vendor/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="../itheme/panel/vendor/datatables.net-bs5/js/dataTables.bootstrap5.min.js"></script>
<script src="../itheme/panel/vendor/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
<script src="../itheme/panel/vendor/datatables.net-responsive-bs5/js/responsive.bootstrap5.min.js"></script>
<script src="../itheme/panel/vendor/datatables.net-fixedcolumns-bs5/js/fixedColumns.bootstrap5.min.js"></script>
<script src="../itheme/panel/vendor/datatables.net-fixedheader/js/dataTables.fixedHeader.min.js"></script>
<script src="../itheme/panel/vendor/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
<script src="../itheme/panel/vendor/datatables.net-buttons-bs5/js/buttons.bootstrap5.min.js"></script>
<script src="../itheme/panel/vendor/datatables.net-buttons/js/buttons.html5.min.js"></script>
<script src="../itheme/panel/vendor/datatables.net-buttons/js/buttons.flash.min.js"></script>
<script src="../itheme/panel/vendor/datatables.net-buttons/js/buttons.print.min.js"></script>
<script src="../itheme/panel/vendor/datatables.net-keytable/js/dataTables.keyTable.min.js"></script>
<script src="../itheme/panel/vendor/datatables.net-select/js/dataTables.select.min.js"></script>
<script src="../itheme/panel/js/pages/demo.datatable-init.js"></script>


<script src="../itheme/panel/vendor/bootstrap-timepicker/js/bootstrap-timepicker.min.js"></script>
<script src="../itheme/panel/vendor/flatpickr/flatpickr.min.js"></script>
<script src="../itheme/panel/js/pages/demo.timepicker.js"></script>
<script src="../itheme/panel/js/app.min.js"></script>
<script src="../itheme/panel/js/jquery.multi-select.js"></script>
<script src="../itheme/panel/js/iw.js"></script>

</body>
</html>