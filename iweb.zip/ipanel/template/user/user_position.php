<?php
///template/user/user_position.php
?>
