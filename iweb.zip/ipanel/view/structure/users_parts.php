<?php
///view/structure/users_parts.php
include './controller/structure/users_parts.php';
include './template/structure/users_parts.php';
