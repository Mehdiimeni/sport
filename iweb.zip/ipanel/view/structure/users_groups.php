<?php
///view/structure/users_groups.php
include './controller/structure/users_groups.php';
include './template/structure/users_groups.php';
