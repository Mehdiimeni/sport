<?php
///view/structure/unit.php
include './controller/structure/unit.php';
include './template/structure/unit.php';
