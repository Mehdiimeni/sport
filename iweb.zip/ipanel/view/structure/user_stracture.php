<?php
///view/structure/user_stracture.php
include './controller/structure/user_stracture.php';
include './template/structure/user_stracture.php';
