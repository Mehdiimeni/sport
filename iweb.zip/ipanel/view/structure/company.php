<?php
///view/structure/company.php
include './controller/structure/company.php';
include './template/structure/company.php';
