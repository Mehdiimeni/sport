<?php
///view/global/menu.php
include './controller/global/menu.php';
include './template/global/menu.php';
