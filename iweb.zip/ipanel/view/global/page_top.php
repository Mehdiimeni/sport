<?php
///view/global/page_top.php
include './controller/global/page_top.php';
include './template/global/page_top.php';
