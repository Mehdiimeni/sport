<?php
///view/organization/provinces.php
include './controller/organization/provinces.php';
include './template/organization/provinces.php';
