<?php
///view/organization/organization_companies.php
include './controller/organization/organization_companies.php';
include './template/organization/organization_companies.php';
