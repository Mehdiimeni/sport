<?php
///view/organization/organization_banks.php
include './controller/organization/organization_banks.php';
include './template/organization/organization_banks.php';
