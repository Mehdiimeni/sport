<?php
///view/financial/remittance_form4.php
include './controller/financial/remittance_form4.php';
include './template/financial/remittance_form4.php';
