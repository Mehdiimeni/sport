<?php
///view/financial/remittance_form3.php
include './controller/financial/remittance_form3.php';
include './template/financial/remittance_form3.php';
