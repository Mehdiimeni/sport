<?php
///view/first/user.php
include './controller/first/user.php';
include './template/first/user.php';
