<?php
///view/user/user_position.php
include './controller/user/user_position.php';
include './template/user/user_position.php';
