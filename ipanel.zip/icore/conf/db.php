
<?php
return [
    'localhost' => [
        'host' => 'localhost',
        'user' => 'root',
        'password' => '',
        'database' => 'sport',
    ],
    'production' => [
        'host' => 'localhost',
        'user' => 'chairblo_sport',
        'password' => 'Massbin44@2',
        'database' => 'chairblo_sport',
    ],
];
?>
