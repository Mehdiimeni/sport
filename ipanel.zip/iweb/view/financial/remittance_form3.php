<?php
///view/financial/remittance_form3.php
include './iweb/controller/financial/remittance_form3.php';
include './iweb/template/financial/remittance_form3.php';
