<?php
///view/financial/remittance_form1_add.php
include './iweb/controller/financial/remittance_form1_add.php';
include './iweb/template/financial/remittance_form1_add.php';
