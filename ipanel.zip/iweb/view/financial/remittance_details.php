<?php
///view/financial/remittance_details.php
include './iweb/controller/financial/remittance_details.php';
include './iweb/template/financial/remittance_details.php';
