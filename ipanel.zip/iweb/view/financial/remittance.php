<?php
///view/financial/remittance.php
include './iweb/controller/financial/remittance.php';
include './iweb/template/financial/remittance.php';
