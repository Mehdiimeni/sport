<?php
///view/user/user_achievements_details.php
include './iweb/controller/user/user_achievements_details.php';
include './iweb/template/user/user_achievements_details.php';
