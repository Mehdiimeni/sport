<?php
///view/user/user_position_details.php
include './iweb/controller/user/user_position_details.php';
include './iweb/template/user/user_position_details.php';
