<?php
///view/global/page_footer_web.php
include './iweb/controller/global/page_footer_web.php';
include './iweb/template/global/page_footer_web.php';
