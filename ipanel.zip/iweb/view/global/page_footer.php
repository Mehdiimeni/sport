<?php
///view/global/page_footer.php
include './iweb/controller/global/page_footer.php';
include './iweb/template/global/page_footer.php';
