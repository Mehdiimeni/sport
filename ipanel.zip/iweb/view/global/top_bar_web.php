<?php
///view/global/top_bar_web.php
include './iweb/controller/global/top_bar_web.php';
include './iweb/template/global/top_bar_web.php';
