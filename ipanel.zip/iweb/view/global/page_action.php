<?php
///view/global/page_action.php
include './iweb/controller/global/page_action.php';
include './iweb/template/global/page_action.php';
