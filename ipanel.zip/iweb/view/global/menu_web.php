<?php
///view/global/menu_web.php
include './iweb/controller/global/menu_web.php';
include './iweb/template/global/menu_web.php';
