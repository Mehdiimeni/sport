<?php
///template/user/logout.php
?>
