<?php
///view/global/page_icon.php
include './controller/global/page_icon.php';
include './template/global/page_icon.php';
