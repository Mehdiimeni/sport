<?php
///view/global/page_js.php
include './controller/global/page_js.php';
include './template/global/page_js.php';
