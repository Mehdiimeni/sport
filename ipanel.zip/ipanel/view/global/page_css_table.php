<?php
///view/global/page_css_table.php
include './controller/global/page_css_table.php';
include './template/global/page_css_table.php';
