<?php
///view/structure/operations.php
include './controller/structure/operations.php';
include './template/structure/operations.php';
