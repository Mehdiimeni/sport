<?php
///view/user/user_position_details.php
include './controller/user/user_position_details.php';
include './template/user/user_position_details.php';
