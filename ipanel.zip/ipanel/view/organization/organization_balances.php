<?php
///view/organization/organization_balances.php
include './controller/organization/organization_balances.php';
include './template/organization/organization_balances.php';
