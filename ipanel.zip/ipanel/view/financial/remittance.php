<?php
///view/financial/remittance.php
include './controller/financial/remittance.php';
include './template/financial/remittance.php';
