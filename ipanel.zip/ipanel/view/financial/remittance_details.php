<?php
///view/financial/remittance_details.php
include './controller/financial/remittance_details.php';
include './template/financial/remittance_details.php';
