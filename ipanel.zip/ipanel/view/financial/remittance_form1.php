<?php
///view/financial/remittance_form1.php
include './controller/financial/remittance_form1.php';
include './template/financial/remittance_form1.php';
