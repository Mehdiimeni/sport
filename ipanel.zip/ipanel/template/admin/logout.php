<?php
///template/admin/logout.php
?>
