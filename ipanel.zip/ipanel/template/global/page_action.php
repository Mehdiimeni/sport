<?php
///template/global/page_action.php
?>
