<?php
///controller/global/page_js_table.php
